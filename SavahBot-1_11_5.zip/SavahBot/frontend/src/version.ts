export const APP_VERSION = "1.11.5";
